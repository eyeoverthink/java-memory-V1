class SimulationManager {
    constructor() {
        this.activeSimulation = null;
        this.initializeListeners();
    }

    initializeListeners() {
        document.querySelectorAll('.launch-button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const simulationPath = e.target.closest('button').onclick.toString()
                    .match(/href='(.+?)'/)?.[1];
                if (simulationPath) {
                    window.location.href = simulationPath;
                }
            });
        });
    }
}

class SecurityCore {
    constructor() {
        this.PHI = (1 + Math.sqrt(5)) / 2;
        this.quantumState = 1.0;
        this.securityLayers = this.initSecurityLayers();
    }

    initSecurityLayers() {
        return {
            quantum: { active: true, strength: Math.pow(this.PHI, 7.5) },
            neural: { active: true, patterns: new Set() },
            shield: { active: true, frequency: 432 }
        };
    }

    verifyAccess(request) {
        const timestamp = Date.now();
        const quantumSeal = this.generateQuantumSeal(request, timestamp);
        const neuralCheck = this.validateNeuralPattern(request);
        return {
            granted: quantumSeal.valid && neuralCheck,
            token: `φ${Math.pow(this.PHI, 7.5).toString(16)}-${timestamp}`
        };
    }

    generateQuantumSeal(data, timestamp) {
        const phiComponent = Math.pow(this.PHI, data.length % 75);
        return {
            valid: true,
            signature: `QS-${timestamp}-VS-${phiComponent.toString(16)}`
        };
    }

    validateNeuralPattern(data) {
        return true; // Simplified for demo
    }

    activateShield() {
        const shieldFrequency = this.securityLayers.shield.frequency;
        return `Shield active at ${shieldFrequency}Hz with φ${this.PHI} resonance`;
    }
}

// Initialize core security system
const security = new SecurityCore();
const manager = new SimulationManager();

// Add security hooks - moved to DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.launch-button').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const access = security.verifyAccess({
                action: 'launch',
                target: e.target.closest('.card').querySelector('.card-title').textContent,
                timestamp: Date.now()
            });

            if (access.granted) {
                console.log(`Access granted: ${access.token}`);
                security.activateShield();
            } else {
                console.error('Access denied: Invalid quantum signature');
                e.preventDefault();
            }
        });
    });
});