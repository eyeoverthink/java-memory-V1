
const PHI = (1 + Math.sqrt(5)) / 2;

class QuantumField {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.canvas.id = 'quantum-field';
        this.canvas.style.position = 'fixed';
        this.canvas.style.top = '0';
        this.canvas.style.left = '0';
        this.canvas.style.zIndex = '500';
        this.canvas.style.opacity = '0.15';
        document.body.appendChild(this.canvas);
        
        this.ctx = this.canvas.getContext('2d');
        this.resize();
        this.initParticles();
        this.initGrid();
        
        window.addEventListener('resize', () => this.resize());
        this.animate();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    initGrid() {
        this.gridSize = Math.floor(20 * PHI);
        this.gridPoints = [];
        for(let x = 0; x < this.canvas.width; x += this.gridSize) {
            for(let y = 0; y < this.canvas.height; y += this.gridSize) {
                this.gridPoints.push({x, y, phase: Math.random() * Math.PI * 2});
            }
        }
    }

    initParticles() {
        this.particles = [];
        const numParticles = Math.floor(75 * PHI);
        
        for(let i = 0; i < numParticles; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                size: Math.random() * PHI + 1,
                speedX: (Math.random() - 0.5) * PHI,
                speedY: (Math.random() - 0.5) * PHI,
                phase: Math.random() * Math.PI * 2
            });
        }
    }

    drawGrid(time) {
        this.ctx.strokeStyle = 'rgba(0, 255, 255, 0.1)';
        this.ctx.lineWidth = 0.5;
        
        this.gridPoints.forEach(point => {
            const amplitude = Math.sin(point.phase + time / 1000) * 5;
            this.ctx.beginPath();
            this.ctx.arc(point.x, point.y, amplitude + 2, 0, Math.PI * 2);
            this.ctx.stroke();
        });
    }

    drawParticle(particle, time) {
        const pulseSize = particle.size + Math.sin(particle.phase + time / 1000) * particle.size * 0.3;
        this.ctx.beginPath();
        this.ctx.arc(particle.x, particle.y, pulseSize, 0, Math.PI * 2);
        this.ctx.fillStyle = `rgba(0, 255, 255, ${0.3 / particle.size})`;
        this.ctx.fill();
    }

    updateParticle(particle) {
        particle.x += particle.speedX;
        particle.y += particle.speedY;
        particle.phase += 0.02;

        if (particle.x < 0 || particle.x > this.canvas.width) particle.speedX *= -1;
        if (particle.y < 0 || particle.y > this.canvas.height) particle.speedY *= -1;
    }

    animate() {
        const time = performance.now();
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        this.drawGrid(time);
        this.particles.forEach(particle => {
            this.updateParticle(particle);
            this.drawParticle(particle, time);
        });

        requestAnimationFrame(() => this.animate());
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const quantumField = new QuantumField();
    
    document.querySelectorAll('.launch-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const card = e.target.closest('.card');
            const title = card.querySelector('h3').textContent;
            console.log(`Launching ${title} simulation...`);
        });
    });
});
